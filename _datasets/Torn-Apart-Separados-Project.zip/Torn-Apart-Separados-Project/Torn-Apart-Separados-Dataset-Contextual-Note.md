## Contextual Note

Torn Apart/ Separados Dataset

Download dataset (as well as additional project data) from the project's [GitHub repository](https://github.com/xpmethod/torn-apart-open-data)

This data is assembled from an export of data from the second installment of the [Torn Apart / Separados Project](http://xpmethod.columbia.edu/torn-apart/volume/2/index) by Manan Ahmed, Alex Gil, Moacir P. de Sá Pereira, Roopika Risam, Maira E. Álvarez, Sylvia A. Fernández, Linda Rodriguez, and Merisa Martinez

The data comes from a web-scrape of the USASpending.gov website, which is paired with data from the ICE detention center data obtained by the Immigrant Legal Resource Center and the National Immigrant Justice Center and published in [a Nov 2017 list](https://immigrantjustice.org/staff/blog/ice-released-its-most-comprehensive-immigration-detention-data-yet)

For more on the composition and origins of the data, scroll down to the [section labeled "Data" on the project credits page](http://xpmethod.columbia.edu/torn-apart/credits.html) for more on the data sources.

For a write-up of the project for *WIRED* magazine by Emily Dreyfuss, see: ["'ICE Is Everywhere’: Using Library Science to Map the Separation Crisis,"](https://www.wired.com/story/ice-is-everywhere-using-library-science-to-map-child-separation/)